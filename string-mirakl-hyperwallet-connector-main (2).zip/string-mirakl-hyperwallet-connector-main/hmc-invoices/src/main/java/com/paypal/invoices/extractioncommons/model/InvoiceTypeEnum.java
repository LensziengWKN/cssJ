package com.paypal.invoices.extractioncommons.model;

public enum InvoiceTypeEnum {

	AUTO_INVOICE, MANUAL_CREDIT

}
