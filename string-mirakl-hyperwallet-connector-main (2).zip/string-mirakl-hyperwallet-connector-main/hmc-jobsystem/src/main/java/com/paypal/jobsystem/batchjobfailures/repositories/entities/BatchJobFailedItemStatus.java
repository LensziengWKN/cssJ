package com.paypal.jobsystem.batchjobfailures.repositories.entities;

/**
 * Batch job failed status items.
 */
public enum BatchJobFailedItemStatus {

	RETRY_PENDING, RETRIES_EXHAUSTED

}
