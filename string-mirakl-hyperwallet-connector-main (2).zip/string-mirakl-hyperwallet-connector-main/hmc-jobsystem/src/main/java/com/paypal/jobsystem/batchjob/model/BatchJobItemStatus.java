package com.paypal.jobsystem.batchjob.model;

public enum BatchJobItemStatus {

	IN_PROGRESS, PENDING, SUCCESSFUL, FAILED, ABORTED

}
