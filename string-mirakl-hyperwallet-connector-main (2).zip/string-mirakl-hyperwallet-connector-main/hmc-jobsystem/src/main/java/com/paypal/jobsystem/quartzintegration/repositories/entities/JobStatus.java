package com.paypal.jobsystem.quartzintegration.repositories.entities;

/**
 * Represents the possible statuses of a job
 */
public enum JobStatus {

	RUNNING, COMPLETED, UNKNOWN

}
