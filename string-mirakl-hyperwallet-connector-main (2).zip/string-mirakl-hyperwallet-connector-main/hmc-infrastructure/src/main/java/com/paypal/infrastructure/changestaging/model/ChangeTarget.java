package com.paypal.infrastructure.changestaging.model;

public enum ChangeTarget {

	MIRAKL

}
