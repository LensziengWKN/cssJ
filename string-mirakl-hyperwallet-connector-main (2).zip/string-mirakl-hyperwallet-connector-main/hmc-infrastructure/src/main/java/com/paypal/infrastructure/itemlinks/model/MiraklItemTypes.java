package com.paypal.infrastructure.itemlinks.model;

/**
 * List of all possible values of Mirakl items.
 */
public enum MiraklItemTypes {

	SHOP, INVOICE

}
