package com.paypal.infrastructure.itemlinks.model;

/**
 * List of all possible values of Hyperwallet items.
 */
public enum HyperwalletItemTypes {

	PROGRAM, BANK_ACCOUNT, USER, BUSINESS_STAKEHOLDER, PAYMENT

}
