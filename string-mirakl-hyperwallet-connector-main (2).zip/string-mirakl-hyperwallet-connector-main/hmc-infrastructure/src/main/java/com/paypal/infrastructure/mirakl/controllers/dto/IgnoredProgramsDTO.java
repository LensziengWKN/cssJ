package com.paypal.infrastructure.mirakl.controllers.dto;

import lombok.Data;

import java.util.List;

@Data
public class IgnoredProgramsDTO {

	List<String> ignoredPrograms;

}
