package com.paypal.infrastructure.changestaging.model;

public enum ChangeOperation {

	UPDATE

}
